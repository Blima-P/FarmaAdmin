package br.com.farmaadmin;

import br.com.farmaadmin.dao.ProdutoDAO;
import br.com.farmaadmin.util.DatabaseConfig;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.sql.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ProdutoDAOTest {

    private ProdutoDAO produtoDAO;

    @BeforeEach
    public void setup() {
        produtoDAO = new ProdutoDAO();
    }

    @Test
    public void testDecrementarEstoque_Sucesso() throws Exception {
        Connection conn = mock(Connection.class);
        PreparedStatement stmt = mock(PreparedStatement.class);

        when(conn.prepareStatement(startsWith("UPDATE produto SET estoque"))).thenReturn(stmt);
        when(stmt.executeUpdate()).thenReturn(1);

        try (MockedStatic<DatabaseConfig> dbMock = Mockito.mockStatic(DatabaseConfig.class)) {
            dbMock.when(DatabaseConfig::getConnection).thenReturn(conn);

            boolean ok = produtoDAO.decrementarEstoque(5, 2);
            assertTrue(ok);
        }
    }

    @Test
    public void testDecrementarEstoque_Falha() throws Exception {
        Connection conn = mock(Connection.class);
        PreparedStatement stmt = mock(PreparedStatement.class);

        when(conn.prepareStatement(startsWith("UPDATE produto SET estoque"))).thenReturn(stmt);
        when(stmt.executeUpdate()).thenReturn(0);

        try (MockedStatic<DatabaseConfig> dbMock = Mockito.mockStatic(DatabaseConfig.class)) {
            dbMock.when(DatabaseConfig::getConnection).thenReturn(conn);

            boolean ok = produtoDAO.decrementarEstoque(5, 10);
            assertFalse(ok);
        }
    }
}
