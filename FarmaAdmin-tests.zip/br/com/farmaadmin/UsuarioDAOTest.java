package br.com.farmaadmin;

import br.com.farmaadmin.dao.UsuarioDAO;
import br.com.farmaadmin.modelo.Usuario;
import br.com.farmaadmin.util.DatabaseConfig;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.sql.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UsuarioDAOTest {

    private UsuarioDAO usuarioDAO;

    @BeforeEach
    public void setup() {
        usuarioDAO = new UsuarioDAO();
    }

    @Test
    public void testBuscarPorId() throws Exception {
        Connection conn = mock(Connection.class);
        PreparedStatement stmt = mock(PreparedStatement.class);
        ResultSet rs = mock(ResultSet.class);

        when(conn.prepareStatement(startsWith("SELECT"))).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(rs);
        when(rs.next()).thenReturn(true);
        when(rs.getInt("id")).thenReturn(1);
        when(rs.getString("nome")).thenReturn("Teste Usuario");
        when(rs.getString("email")).thenReturn("teste@example.com");

        try (MockedStatic<DatabaseConfig> dbMock = Mockito.mockStatic(DatabaseConfig.class)) {
            dbMock.when(DatabaseConfig::getConnection).thenReturn(conn);

            Usuario u = usuarioDAO.buscarPorId(1);
            assertNotNull(u);
            assertEquals("Teste Usuario", u.getNome());
            assertEquals("teste@example.com", u.getEmail());
        }
    }
}
