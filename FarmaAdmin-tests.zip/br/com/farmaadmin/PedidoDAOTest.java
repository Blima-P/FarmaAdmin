package br.com.farmaadmin;

import br.com.farmaadmin.dao.PedidoDAO;
import br.com.farmaadmin.dao.ProdutoDAO;
import br.com.farmaadmin.modelo.Pedido;
import br.com.farmaadmin.modelo.Produto;
import br.com.farmaadmin.util.DatabaseConfig;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.sql.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class PedidoDAOTest {

    private PedidoDAO pedidoDAO;

    @BeforeEach
    public void setup() {
        pedidoDAO = new PedidoDAO();
    }

    @Test
    public void testRegistrarNovoPedido_Sucesso() throws Exception {
        // mocks
        Connection conn = mock(Connection.class);
        PreparedStatement stmtPedido = mock(PreparedStatement.class);
        PreparedStatement stmtItens = mock(PreparedStatement.class);
        ResultSet generatedKeys = mock(ResultSet.class);

        when(conn.prepareStatement(startsWith("INSERT INTO pedido"), anyInt())).thenReturn(stmtPedido);
        when(conn.prepareStatement(startsWith("INSERT INTO itens_pedido"))).thenReturn(stmtItens);
        when(stmtPedido.executeUpdate()).thenReturn(1);
        when(stmtPedido.getGeneratedKeys()).thenReturn(generatedKeys);
        when(generatedKeys.next()).thenReturn(true);
        when(generatedKeys.getInt(1)).thenReturn(42);

        // mock produtoDAO dentro de PedidoDAO (substituir via reflection)
        ProdutoDAO produtoDAOMock = mock(ProdutoDAO.class);
        when(produtoDAOMock.decrementarEstoque(anyInt(), anyInt())).thenReturn(true);

        // mock DatabaseConfig.getConnection() static
        try (MockedStatic<DatabaseConfig> dbMock = Mockito.mockStatic(DatabaseConfig.class)) {
            dbMock.when(DatabaseConfig::getConnection).thenReturn(conn);

            // inject produtoDAOMock via reflection
            java.lang.reflect.Field f = PedidoDAO.class.getDeclaredField("produtoDAO");
            f.setAccessible(true);
            f.set(pedidoDAO, produtoDAOMock);

            // prepare input
            Pedido p = new Pedido();
            p.setUsuarioId(1);
            p.setValorTotal(100.0);
            p.setEnderecoEntrega("Rua Teste");
            p.setStatus("EM_PROCESSAMENTO");

            Produto item = new Produto();
            item.setId(10);
            item.setEstoque(2);
            item.setPreco(50.0);

            Pedido result = pedidoDAO.registrarNovoPedido(p, java.util.List.of(item));
            assertNotNull(result);
            assertEquals(42, result.getId());
            verify(conn).commit();
        }
    }

    @Test
    public void testRegistrarNovoPedido_EstoqueInsuficiente() throws Exception {
        Connection conn = mock(Connection.class);
        PreparedStatement stmtPedido = mock(PreparedStatement.class);
        PreparedStatement stmtItens = mock(PreparedStatement.class);
        ResultSet generatedKeys = mock(ResultSet.class);

        when(conn.prepareStatement(startsWith("INSERT INTO pedido"), anyInt())).thenReturn(stmtPedido);
        when(conn.prepareStatement(startsWith("INSERT INTO itens_pedido"))).thenReturn(stmtItens);
        when(stmtPedido.executeUpdate()).thenReturn(1);
        when(stmtPedido.getGeneratedKeys()).thenReturn(generatedKeys);
        when(generatedKeys.next()).thenReturn(true);
        when(generatedKeys.getInt(1)).thenReturn(43);

        ProdutoDAO produtoDAOMock = mock(ProdutoDAO.class);
        when(produtoDAOMock.decrementarEstoque(anyInt(), anyInt())).thenReturn(false); // insuficiente

        try (MockedStatic<DatabaseConfig> dbMock = Mockito.mockStatic(DatabaseConfig.class)) {
            dbMock.when(DatabaseConfig::getConnection).thenReturn(conn);

            java.lang.reflect.Field f = PedidoDAO.class.getDeclaredField("produtoDAO");
            f.setAccessible(true);
            f.set(pedidoDAO, produtoDAOMock);

            Pedido p = new Pedido();
            p.setUsuarioId(1);
            p.setValorTotal(100.0);
            p.setEnderecoEntrega("Rua Teste");
            p.setStatus("EM_PROCESSAMENTO");

            Produto item = new Produto();
            item.setId(10);
            item.setEstoque(5);
            item.setPreco(20.0);

            assertThrows(SQLException.class, () -> pedidoDAO.registrarNovoPedido(p, java.util.List.of(item)));
            verify(conn).rollback();
        }
    }
}
